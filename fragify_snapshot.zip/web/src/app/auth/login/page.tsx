'use client'
import { useState, useEffect, Suspense } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'

const NEXTAUTH_URL = 'https://fragify.miniserver.online'

const S = {
  wrap:    { minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px 16px' },
  card:    { background:'var(--bg-card)', border:'1px solid var(--bg-border)', borderRadius:12, padding:'40px', width:'100%', maxWidth:420 },
  logo:    { fontFamily:'Rajdhani,sans-serif', fontWeight:700, fontSize:28, textAlign:'center' as const, marginBottom:4 },
  sub:     { color:'var(--t3)', fontSize:12, textAlign:'center' as const, marginBottom:32 },
  label:   { fontSize:12, fontWeight:500, color:'var(--t2)', display:'block', marginBottom:6 },
  input:   { width:'100%', background:'#0d0e13', border:'1px solid var(--bg-border)', borderRadius:6, padding:'10px 12px', fontSize:13, color:'var(--t1)', outline:'none', boxSizing:'border-box' as const },
  btn:     { width:'100%', background:'var(--orange)', color:'#fff', fontWeight:700, fontSize:14, padding:'11px', borderRadius:8, border:'none', cursor:'pointer', marginTop:8 },
  steamBtn:{ width:'100%', background:'#1b2838', color:'#c6d4df', fontWeight:600, fontSize:13, padding:'11px', borderRadius:8, border:'1px solid #2a475e', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:10 },
  divider: { display:'flex', alignItems:'center', gap:12, margin:'20px 0' },
  divLine: { flex:1, height:1, background:'var(--bg-border)' },
  divText: { fontSize:11, color:'var(--t3)', whiteSpace:'nowrap' as const },
  error:   { background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:6, padding:'10px 12px', fontSize:13, color:'#ef4444', marginBottom:16 },
  success: { background:'rgba(34,197,94,0.1)', border:'1px solid rgba(34,197,94,0.3)', borderRadius:6, padding:'10px 12px', fontSize:13, color:'#22c55e', marginBottom:16 },
  field:   { marginBottom:16 },
}

function buildSteamOpenIDUrl() {
  const params = new URLSearchParams({
    'openid.ns':         'http://specs.openid.net/auth/2.0',
    'openid.mode':       'checkid_setup',
    'openid.return_to':  `${NEXTAUTH_URL}/api/auth/steam/callback`,
    'openid.realm':      NEXTAUTH_URL,
    'openid.identity':   'http://specs.openid.net/auth/2.0/identifier_select',
    'openid.claimed_id': 'http://specs.openid.net/auth/2.0/identifier_select',
  })
  return `https://steamcommunity.com/openid/login?${params.toString()}`
}

function LoginForm() {
  const router       = useRouter()
  const searchParams = useSearchParams()
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState('')
  const [success,  setSuccess]  = useState('')
  // 2FA state
  const [twoFaStep,   setTwoFaStep]   = useState(false)
  const [twoFaMethod, setTwoFaMethod] = useState<'TOTP'|'EMAIL'|null>(null)
  const [twoFaCode,   setTwoFaCode]   = useState('')
  const [twoFaUserId, setTwoFaUserId] = useState<string|null>(null)
  const [backupMode,  setBackupMode]  = useState(false)
  const [backupCode,  setBackupCode]  = useState('')
  const [sending2FA,  setSending2FA]  = useState(false)

  useEffect(() => {
    const verified = searchParams.get('verified')
    const isSteam  = searchParams.get('steam') === '1'
    if (verified === '1') {
      setSuccess(
        isSteam
          ? 'Email verified! Your email is now linked to your Steam account.'
          : 'Email verified! You can now log in.'
      )
    }
    const err = searchParams.get('error')
    if (err === 'invalid_or_expired_token') setError('Verification link is invalid or expired.')
    if (err === 'EMAIL_NOT_VERIFIED')       setError('Please verify your email before logging in.')
    if (err === 'SteamFailed')              setError('Steam authentication failed. Please try again.')
    if (err === 'SteamInvalid')             setError('Steam authentication invalid. Please try again.')
    if (err === 'Configuration')            setError('Authentication configuration error. Please try again.')
  }, [searchParams])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')

    // Verificar si tiene 2FA antes de hacer signIn
    const checkRes = await fetch('/api/auth/2fa/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    const checkData = await checkRes.json()
    setLoading(false)

    if (!checkRes.ok) {
      if (checkData.error === 'EMAIL_NOT_VERIFIED') setError('Please verify your email before logging in.')
      else if (checkData.error === 'USE_STEAM')     setError('This account was created with Steam. Please use Sign in with Steam.')
      else setError(checkData.error ?? 'Invalid email or password.')
      return
    }

    // Si tiene 2FA activo → paso de verificación
    if (checkData.requires2FA) {
      setTwoFaUserId(checkData.userId)
      setTwoFaMethod(checkData.method)
      setTwoFaStep(true)
      // Si es EMAIL → solicitar OTP automáticamente
      if (checkData.method === 'EMAIL') {
        setSending2FA(true)
        await fetch('/api/auth/2fa/verify', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: checkData.userId }),
        })
        setSending2FA(false)
      }
      return
    }

    // Sin 2FA → login normal
    const res = await signIn('credentials', { email, password, redirect: false })
    if (res?.error) {
      if (res.error === 'EMAIL_NOT_VERIFIED') setError('Please verify your email before logging in.')
      else if (res.error === 'USE_STEAM')     setError('This account was created with Steam. Please use Sign in with Steam.')
      else setError('Invalid email or password.')
    } else {
      router.push('/profile')
    }
  }

  async function handle2FASubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    const body: any = backupMode
      ? { userId: twoFaUserId, backup: backupCode }
      : { userId: twoFaUserId, code: twoFaCode }

    const res  = await fetch('/api/auth/2fa/verify', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    })
    const data = await res.json()
    if (!res.ok) { setLoading(false); setError(data.error ?? 'Código incorrecto'); return }

    // 2FA OK → completar login
    const signRes = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)
    if (signRes?.error) { setError('Error al completar el login'); return }
    router.push('/profile')
  }

  function handleSteamLogin() {
    window.location.href = buildSteamOpenIDUrl()
  }

  // Pantalla de verificación 2FA
  if (twoFaStep) {
    return (
      <div style={S.wrap}>
        <div style={S.card}>
          <div style={S.logo}>FRAG<span style={{ color:'var(--orange)' }}>IFY</span></div>
          <div style={S.sub}>Two-Factor Authentication</div>

          {error && <div style={S.error}>{error}</div>}

          {sending2FA ? (
            <div style={{ textAlign:'center', color:'var(--t3)', padding:'20px 0' }}>
              Sending code to your email...
            </div>
          ) : (
            <form onSubmit={handle2FASubmit}>
              {!backupMode ? (
                <>
                  <div style={{ textAlign:'center', fontSize:13, color:'var(--t2)', marginBottom:20 }}>
                    {twoFaMethod === 'TOTP'
                      ? '🔐 Enter the 6-digit code from your authenticator app.'
                      : '📧 Enter the 6-digit code sent to your email.'}
                  </div>
                  <div style={S.field}>
                    <label style={S.label}>Verification Code</label>
                    <input
                      type="text" inputMode="numeric" pattern="[0-9]{6}"
                      maxLength={6} value={twoFaCode}
                      onChange={e => setTwoFaCode(e.target.value.replace(/\D/g,''))}
                      style={{ ...S.input, textAlign:'center', fontSize:24, letterSpacing:'8px', fontFamily:'monospace' }}
                      placeholder="000000" autoFocus required
                      onFocus={e => (e.target.style.borderColor = 'var(--orange)')}
                      onBlur={e  => (e.target.style.borderColor = 'var(--bg-border)')}
                    />
                  </div>
                  <button type="submit" disabled={loading || twoFaCode.length < 6}
                          style={{ ...S.btn, opacity: (loading || twoFaCode.length < 6) ? 0.6 : 1 }}>
                    {loading ? 'Verifying...' : 'Verify'}
                  </button>
                  {twoFaMethod === 'EMAIL' && (
                    <button type="button" onClick={async () => {
                      setSending2FA(true)
                      await fetch('/api/auth/2fa/verify', {
                        method: 'PUT', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId: twoFaUserId }),
                      })
                      setSending2FA(false)
                    }} style={{ ...S.btn, marginTop:8, background:'transparent',
                                border:'1px solid var(--bg-border)', color:'var(--t3)' }}>
                      Resend code
                    </button>
                  )}
                </>
              ) : (
                <>
                  <div style={{ textAlign:'center', fontSize:13, color:'var(--t2)', marginBottom:20 }}>
                    🔑 Enter your 8-character backup code.
                  </div>
                  <div style={S.field}>
                    <label style={S.label}>Backup Code</label>
                    <input
                      type="text" value={backupCode}
                      onChange={e => setBackupCode(e.target.value.toUpperCase())}
                      style={{ ...S.input, textAlign:'center', fontSize:16, letterSpacing:'4px', fontFamily:'monospace' }}
                      placeholder="XXXXXXXX" maxLength={8} autoFocus required
                      onFocus={e => (e.target.style.borderColor = 'var(--orange)')}
                      onBlur={e  => (e.target.style.borderColor = 'var(--bg-border)')}
                    />
                  </div>
                  <button type="submit" disabled={loading}
                          style={{ ...S.btn, opacity: loading ? 0.6 : 1 }}>
                    {loading ? 'Verifying...' : 'Use Backup Code'}
                  </button>
                </>
              )}
              <div style={{ textAlign:'center', marginTop:16, fontSize:12 }}>
                <button type="button" onClick={() => { setBackupMode(b => !b); setError('') }}
                        style={{ background:'none', border:'none', color:'var(--orange)', cursor:'pointer', fontSize:12 }}>
                  {backupMode ? '← Back to verification code' : "Lost access? Use backup code"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    )
  }

  return (
    <div style={S.wrap}>
      <div style={S.card}>
        <div style={S.logo}>FRAG<span style={{ color:'var(--orange)' }}>IFY</span></div>
        <div style={S.sub}>Sign in to your account</div>

        {error   && <div style={S.error}>{error}</div>}
        {success && <div style={S.success}>{success}</div>}

        <button onClick={handleSteamLogin} style={S.steamBtn}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#c6d4df">
            <path d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.718L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.606 0 11.979 0z"/>
          </svg>
          Sign in with Steam
        </button>

        <div style={S.divider}>
          <div style={S.divLine}/><span style={S.divText}>or sign in with email</span><div style={S.divLine}/>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={S.field}>
            <label style={S.label}>Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              style={S.input} placeholder="you@example.com" required
              onFocus={e => (e.target.style.borderColor = 'var(--orange)')}
              onBlur={e  => (e.target.style.borderColor = 'var(--bg-border)')}
            />
          </div>
          <div style={S.field}>
            <label style={S.label}>Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)}
              style={S.input} placeholder="••••••••" required
              onFocus={e => (e.target.style.borderColor = 'var(--orange)')}
              onBlur={e  => (e.target.style.borderColor = 'var(--bg-border)')}
            />
          </div>
          <button type="submit" disabled={loading} style={{ ...S.btn, opacity: loading ? 0.7 : 1 }}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <div style={{ textAlign:'center', marginTop:20, fontSize:13, color:'var(--t3)' }}>
          Don't have an account?{' '}
          <Link href="/auth/register" style={{ color:'var(--orange)' }}>Create one</Link>
        </div>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div style={{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--t2)' }}>Loading...</div>}>
      <LoginForm />
    </Suspense>
  )
}
